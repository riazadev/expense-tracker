package com.riazadev.expensetracker.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.riazadev.expensetracker.domain.Category

@Entity(tableName = "expenses")
data class ExpenseEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    val title: String,

    /** Importe en céntimos: evita errores de redondeo de los decimales en coma flotante. */
    val amountCents: Long,

    val category: Category,

    /** Fecha del gasto como epochDay (días desde 1970-01-01). */
    val dateEpochDay: Long,

    val note: String? = null
)
