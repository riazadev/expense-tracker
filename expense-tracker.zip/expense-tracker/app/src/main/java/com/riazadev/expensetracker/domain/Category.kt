package com.riazadev.expensetracker.domain

/**
 * Categorías de gasto disponibles.
 * El nombre visible se guarda aquí para no duplicarlo por toda la UI.
 */
enum class Category(val label: String) {
    FOOD("Comida"),
    TRANSPORT("Transporte"),
    HOUSING("Vivienda"),
    LEISURE("Ocio"),
    HEALTH("Salud"),
    SHOPPING("Compras"),
    OTHER("Otros")
}
