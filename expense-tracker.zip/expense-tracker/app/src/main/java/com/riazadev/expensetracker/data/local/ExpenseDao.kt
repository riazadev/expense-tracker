package com.riazadev.expensetracker.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.riazadev.expensetracker.domain.Category
import kotlinx.coroutines.flow.Flow

/**
 * Resultado de la agregación de gasto por categoría.
 */
data class CategoryTotal(
    val category: Category,
    val totalCents: Long
)

@Dao
interface ExpenseDao {

    @Query("SELECT * FROM expenses ORDER BY dateEpochDay DESC, id DESC")
    fun observeAll(): Flow<List<ExpenseEntity>>

    @Query(
        """
        SELECT * FROM expenses
        WHERE dateEpochDay BETWEEN :fromEpochDay AND :toEpochDay
        ORDER BY dateEpochDay DESC, id DESC
        """
    )
    fun observeBetween(fromEpochDay: Long, toEpochDay: Long): Flow<List<ExpenseEntity>>

    @Query(
        """
        SELECT COALESCE(SUM(amountCents), 0) FROM expenses
        WHERE dateEpochDay BETWEEN :fromEpochDay AND :toEpochDay
        """
    )
    fun observeTotalBetween(fromEpochDay: Long, toEpochDay: Long): Flow<Long>

    @Query(
        """
        SELECT category AS category, SUM(amountCents) AS totalCents
        FROM expenses
        WHERE dateEpochDay BETWEEN :fromEpochDay AND :toEpochDay
        GROUP BY category
        ORDER BY totalCents DESC
        """
    )
    fun observeTotalsByCategory(fromEpochDay: Long, toEpochDay: Long): Flow<List<CategoryTotal>>

    @Query("SELECT * FROM expenses WHERE id = :id")
    suspend fun findById(id: Long): ExpenseEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(expense: ExpenseEntity): Long

    @Update
    suspend fun update(expense: ExpenseEntity)

    @Delete
    suspend fun delete(expense: ExpenseEntity)
}
