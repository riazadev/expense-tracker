package com.riazadev.expensetracker.data.repository

import com.riazadev.expensetracker.data.local.CategoryTotal
import com.riazadev.expensetracker.data.local.ExpenseDao
import com.riazadev.expensetracker.data.local.ExpenseEntity
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Única fuente de verdad para los gastos.
 * La UI nunca habla directamente con el DAO: pasa siempre por aquí.
 */
@Singleton
class ExpenseRepository @Inject constructor(
    private val dao: ExpenseDao
) {
    fun observeAll(): Flow<List<ExpenseEntity>> = dao.observeAll()

    fun observeBetween(fromEpochDay: Long, toEpochDay: Long): Flow<List<ExpenseEntity>> =
        dao.observeBetween(fromEpochDay, toEpochDay)

    fun observeTotalBetween(fromEpochDay: Long, toEpochDay: Long): Flow<Long> =
        dao.observeTotalBetween(fromEpochDay, toEpochDay)

    fun observeTotalsByCategory(fromEpochDay: Long, toEpochDay: Long): Flow<List<CategoryTotal>> =
        dao.observeTotalsByCategory(fromEpochDay, toEpochDay)

    suspend fun findById(id: Long): ExpenseEntity? = dao.findById(id)

    suspend fun save(expense: ExpenseEntity): Long =
        if (expense.id == 0L) {
            dao.insert(expense)
        } else {
            dao.update(expense)
            expense.id
        }

    suspend fun delete(expense: ExpenseEntity) = dao.delete(expense)
}
