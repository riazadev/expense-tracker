package com.riazadev.expensetracker.data.local

import androidx.room.TypeConverter
import com.riazadev.expensetracker.domain.Category

class Converters {

    @TypeConverter
    fun fromCategory(category: Category): String = category.name

    @TypeConverter
    fun toCategory(value: String): Category = Category.valueOf(value)
}
