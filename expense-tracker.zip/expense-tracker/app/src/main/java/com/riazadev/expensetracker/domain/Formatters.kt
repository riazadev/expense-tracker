package com.riazadev.expensetracker.domain

import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

object Formatters {

    private val dateFormatter = DateTimeFormatter.ofPattern("d MMM yyyy", Locale("es", "ES"))

    /**
     * Convierte céntimos a una cadena legible: 1234 -> "12,34 €"
     */
    fun formatCents(cents: Long): String {
        val euros = cents / 100
        val remainder = (cents % 100).toString().padStart(2, '0')
        return "$euros,$remainder €"
    }

    /**
     * Convierte el texto introducido por el usuario ("12,34" o "12.34") a céntimos.
     * Devuelve null si el formato no es válido.
     */
    fun parseAmountToCents(input: String): Long? {
        val normalized = input.trim().replace(',', '.')
        if (normalized.isEmpty()) return null
        val value = normalized.toDoubleOrNull() ?: return null
        if (value < 0) return null
        return Math.round(value * 100)
    }

    fun formatDate(epochDay: Long): String =
        LocalDate.ofEpochDay(epochDay).format(dateFormatter)
}
