package com.riazadev.expensetracker.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = Navy700,
    onPrimary = Color.White,
    secondary = Teal500,
    onSecondary = Color.White,
    tertiary = Teal400,
    background = SurfaceLight,
    onBackground = TextDark,
    surface = Color.White,
    onSurface = TextDark,
    error = DangerRed
)

private val DarkColors = darkColorScheme(
    primary = Teal400,
    onPrimary = Navy950,
    secondary = Teal200,
    onSecondary = Navy950,
    tertiary = Teal500,
    background = Navy950,
    onBackground = Color.White,
    surface = Navy900,
    onSurface = Color.White,
    error = DangerRed
)

@Composable
fun ExpenseTrackerTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = Typography,
        content = content
    )
}
