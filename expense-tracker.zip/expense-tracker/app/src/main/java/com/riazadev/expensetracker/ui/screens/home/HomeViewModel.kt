package com.riazadev.expensetracker.ui.screens.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.riazadev.expensetracker.data.local.CategoryTotal
import com.riazadev.expensetracker.data.local.ExpenseEntity
import com.riazadev.expensetracker.data.repository.ExpenseRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.YearMonth
import javax.inject.Inject

data class HomeUiState(
    val month: YearMonth = YearMonth.now(),
    val expenses: List<ExpenseEntity> = emptyList(),
    val totalCents: Long = 0,
    val byCategory: List<CategoryTotal> = emptyList(),
    val isLoading: Boolean = true
)

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class HomeViewModel @Inject constructor(
    private val repository: ExpenseRepository
) : ViewModel() {

    private val selectedMonth = MutableStateFlow(YearMonth.now())

    private val expensesFlow = selectedMonth.flatMapLatest { month ->
        val (from, to) = month.toEpochDayRange()
        repository.observeBetween(from, to)
    }

    private val totalFlow = selectedMonth.flatMapLatest { month ->
        val (from, to) = month.toEpochDayRange()
        repository.observeTotalBetween(from, to)
    }

    private val byCategoryFlow = selectedMonth.flatMapLatest { month ->
        val (from, to) = month.toEpochDayRange()
        repository.observeTotalsByCategory(from, to)
    }

    val uiState: StateFlow<HomeUiState> = combine(
        selectedMonth,
        expensesFlow,
        totalFlow,
        byCategoryFlow
    ) { month, expenses, total, byCategory ->
        HomeUiState(
            month = month,
            expenses = expenses,
            totalCents = total,
            byCategory = byCategory,
            isLoading = false
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = HomeUiState()
    )

    fun previousMonth() {
        selectedMonth.value = selectedMonth.value.minusMonths(1)
    }

    fun nextMonth() {
        selectedMonth.value = selectedMonth.value.plusMonths(1)
    }

    fun deleteExpense(expense: ExpenseEntity) {
        viewModelScope.launch {
            repository.delete(expense)
        }
    }
}

/**
 * Devuelve el rango [primer día, último día] del mes en epochDay,
 * que es el formato en el que se guardan las fechas en la base de datos.
 */
fun YearMonth.toEpochDayRange(): Pair<Long, Long> {
    val first: LocalDate = this.atDay(1)
    val last: LocalDate = this.atEndOfMonth()
    return first.toEpochDay() to last.toEpochDay()
}
