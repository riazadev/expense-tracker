package com.riazadev.expensetracker.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.riazadev.expensetracker.ui.screens.addexpense.AddExpenseScreen
import com.riazadev.expensetracker.ui.screens.home.HomeScreen

object Routes {
    const val HOME = "home"
    const val ADD_EXPENSE = "expense"
    const val EXPENSE_ID_ARG = "expenseId"
}

@Composable
fun AppNavigation() {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = Routes.HOME) {

        composable(Routes.HOME) {
            HomeScreen(
                onAddExpense = { navController.navigate("${Routes.ADD_EXPENSE}/0") },
                onEditExpense = { id -> navController.navigate("${Routes.ADD_EXPENSE}/$id") }
            )
        }

        composable(
            route = "${Routes.ADD_EXPENSE}/{${Routes.EXPENSE_ID_ARG}}",
            arguments = listOf(
                navArgument(Routes.EXPENSE_ID_ARG) {
                    type = NavType.LongType
                    defaultValue = 0L
                }
            )
        ) {
            AddExpenseScreen(
                onDone = { navController.popBackStack() }
            )
        }
    }
}
