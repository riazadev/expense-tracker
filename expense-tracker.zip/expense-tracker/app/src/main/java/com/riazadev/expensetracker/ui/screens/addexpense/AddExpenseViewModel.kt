package com.riazadev.expensetracker.ui.screens.addexpense

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.riazadev.expensetracker.data.local.ExpenseEntity
import com.riazadev.expensetracker.data.repository.ExpenseRepository
import com.riazadev.expensetracker.domain.Category
import com.riazadev.expensetracker.domain.Formatters
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.time.LocalDate
import javax.inject.Inject

data class AddExpenseUiState(
    val id: Long = 0,
    val title: String = "",
    val amount: String = "",
    val category: Category = Category.FOOD,
    val dateEpochDay: Long = LocalDate.now().toEpochDay(),
    val note: String = "",
    val titleError: String? = null,
    val amountError: String? = null,
    val saved: Boolean = false
) {
    val isEditing: Boolean get() = id != 0L
}

@HiltViewModel
class AddExpenseViewModel @Inject constructor(
    private val repository: ExpenseRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val _uiState = MutableStateFlow(AddExpenseUiState())
    val uiState: StateFlow<AddExpenseUiState> = _uiState.asStateFlow()

    init {
        val expenseId = savedStateHandle.get<Long>("expenseId") ?: 0L
        if (expenseId != 0L) {
            loadExpense(expenseId)
        }
    }

    private fun loadExpense(id: Long) {
        viewModelScope.launch {
            repository.findById(id)?.let { expense ->
                _uiState.update {
                    it.copy(
                        id = expense.id,
                        title = expense.title,
                        amount = (expense.amountCents / 100.0).toString().replace('.', ','),
                        category = expense.category,
                        dateEpochDay = expense.dateEpochDay,
                        note = expense.note.orEmpty()
                    )
                }
            }
        }
    }

    fun onTitleChange(value: String) {
        _uiState.update { it.copy(title = value, titleError = null) }
    }

    fun onAmountChange(value: String) {
        _uiState.update { it.copy(amount = value, amountError = null) }
    }

    fun onCategoryChange(value: Category) {
        _uiState.update { it.copy(category = value) }
    }

    fun onDateChange(epochDay: Long) {
        _uiState.update { it.copy(dateEpochDay = epochDay) }
    }

    fun onNoteChange(value: String) {
        _uiState.update { it.copy(note = value) }
    }

    fun save() {
        val state = _uiState.value

        val titleError = if (state.title.isBlank()) "Escribe una descripción" else null
        val amountCents = Formatters.parseAmountToCents(state.amount)
        val amountError = when {
            state.amount.isBlank() -> "Introduce el importe"
            amountCents == null -> "Importe no válido"
            amountCents == 0L -> "El importe debe ser mayor que 0"
            else -> null
        }

        if (titleError != null || amountError != null) {
            _uiState.update { it.copy(titleError = titleError, amountError = amountError) }
            return
        }

        viewModelScope.launch {
            repository.save(
                ExpenseEntity(
                    id = state.id,
                    title = state.title.trim(),
                    amountCents = amountCents!!,
                    category = state.category,
                    dateEpochDay = state.dateEpochDay,
                    note = state.note.trim().takeIf { it.isNotEmpty() }
                )
            )
            _uiState.update { it.copy(saved = true) }
        }
    }
}
