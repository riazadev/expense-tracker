package com.riazadev.expensetracker.ui.theme

import androidx.compose.ui.graphics.Color

// Paleta navy/teal, coherente con el resto de mi portfolio
val Navy950 = Color(0xFF0A1930)
val Navy900 = Color(0xFF0F2A4A)
val Navy700 = Color(0xFF16305C)
val Teal500 = Color(0xFF4A9C8A)
val Teal400 = Color(0xFF5FB7A5)
val Teal200 = Color(0xFFA8DED0)
val SurfaceLight = Color(0xFFF5F7FA)
val TextDark = Color(0xFF1C2733)
val TextMuted = Color(0xFF64748B)
val DangerRed = Color(0xFFD64545)
