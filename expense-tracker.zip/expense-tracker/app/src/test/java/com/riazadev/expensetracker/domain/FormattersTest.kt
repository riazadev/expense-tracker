package com.riazadev.expensetracker.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

/**
 * Tests de la conversión de importes.
 * Es la lógica más delicada de la app: todo se guarda en céntimos (Long)
 * para evitar los errores de redondeo típicos de usar Double para dinero.
 */
class FormattersTest {

    @Test
    fun `formatCents formatea correctamente importes con decimales`() {
        assertEquals("12,34 €", Formatters.formatCents(1234))
        assertEquals("0,05 €", Formatters.formatCents(5))
        assertEquals("100,00 €", Formatters.formatCents(10000))
    }

    @Test
    fun `formatCents rellena con cero los decimales de un solo digito`() {
        assertEquals("3,50 €", Formatters.formatCents(350))
        assertEquals("1,07 €", Formatters.formatCents(107))
    }

    @Test
    fun `parseAmountToCents acepta coma y punto como separador decimal`() {
        assertEquals(1234L, Formatters.parseAmountToCents("12,34"))
        assertEquals(1234L, Formatters.parseAmountToCents("12.34"))
    }

    @Test
    fun `parseAmountToCents redondea correctamente los decimales`() {
        assertEquals(1235L, Formatters.parseAmountToCents("12.345"))
        assertEquals(1000L, Formatters.parseAmountToCents("10"))
    }

    @Test
    fun `parseAmountToCents devuelve null con entradas invalidas`() {
        assertNull(Formatters.parseAmountToCents(""))
        assertNull(Formatters.parseAmountToCents("abc"))
        assertNull(Formatters.parseAmountToCents("-5"))
    }

    @Test
    fun `parseAmountToCents ignora espacios sobrantes`() {
        assertEquals(500L, Formatters.parseAmountToCents("  5  "))
    }
}
