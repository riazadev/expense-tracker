# Reglas por defecto de Android
-keepattributes *Annotation*
