# 💰 Expense Tracker

App Android nativa para registrar y analizar gastos personales. **100% offline**: todos los datos viven en el dispositivo mediante Room, sin backend ni conexión necesaria.

![Kotlin](https://img.shields.io/badge/Kotlin-7F52FF?style=for-the-badge&logo=kotlin&logoColor=white)
![Jetpack Compose](https://img.shields.io/badge/Jetpack_Compose-3DDC84?style=for-the-badge&logo=jetpackcompose&logoColor=white)
![Room](https://img.shields.io/badge/Room-4285F4?style=for-the-badge&logo=android&logoColor=white)
![Hilt](https://img.shields.io/badge/Hilt-2C4AA8?style=for-the-badge&logo=dagger&logoColor=white)

## 🧱 Arquitectura

Arquitectura MVVM en capas, con flujo de datos unidireccional:

```
Compose UI → ViewModel (StateFlow) → Repository → DAO (Room)
```

- **UI declarativa** con Jetpack Compose y Material 3 (tema claro y oscuro).
- **Estado reactivo**: el DAO expone `Flow`, así que cualquier cambio en la base de datos se refleja en la interfaz automáticamente, sin recargar a mano.
- **Inyección de dependencias** con Hilt (`@HiltViewModel`, módulo de base de datos).
- **Navegación** con Navigation Compose, con argumento de ruta para reutilizar la misma pantalla en modo crear y editar.

## 💡 Decisiones técnicas

**Los importes se guardan en céntimos (`Long`), no en `Double`.** Usar coma flotante para dinero provoca errores de redondeo acumulativos (el clásico `0.1 + 0.2 != 0.3`). Guardando céntimos como entero, las sumas son exactas. La conversión a texto y viceversa está centralizada en `Formatters` y cubierta por tests.

**Las fechas se guardan como `epochDay` (`Long`).** Simplifica las consultas de rango en SQL (`BETWEEN`) para filtrar por mes sin depender del formato de fecha de SQLite.

**Las agregaciones se hacen en SQL, no en Kotlin.** El total del mes y el desglose por categoría se calculan con `SUM` y `GROUP BY` en el propio DAO, en vez de traer todos los gastos a memoria y recorrerlos.

## ⚙️ Funcionalidades

- Registro de gastos con descripción, importe, categoría, fecha y nota
- Navegación entre meses, con total del periodo
- Desglose visual por categoría, con barras proporcionales al gasto
- Edición y eliminación de gastos existentes
- Tema claro/oscuro según el sistema

## ▶️ Cómo ejecutarlo

```bash
./gradlew assembleDebug
```

O abre el proyecto en Android Studio y ejecuta sobre un emulador o dispositivo (mínimo Android 8.0 / API 26).

Para los tests unitarios:
```bash
./gradlew test
```

---

Proyecto personal de portfolio — [David Riaza Meléndez](https://github.com/riazadev)
